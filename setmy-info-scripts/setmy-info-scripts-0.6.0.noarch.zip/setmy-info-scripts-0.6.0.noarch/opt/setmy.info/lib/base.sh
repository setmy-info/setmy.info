# Copyright 2018 Imre Tabur <imre.tabur@eesti.ee>

export PROVIDER=setmy.info
export VERSION=0.6.0
export COMMAND_NAME=`basename $0`
BINARY_COMMAND_NAME=/opt/setmy.info/bin/$COMMAND_NAME.bin
export LD_LIBRARY_PATH=/opt/setmy.info/lib:$LD_LIBRARY_PATH
export CUR_DIR=`pwd`
